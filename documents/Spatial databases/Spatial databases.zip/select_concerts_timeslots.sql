select
*
from
eot.timetable_view
where
start_time >= '18:00'
and
end_time < '23:00'
and
day = 'sunday';