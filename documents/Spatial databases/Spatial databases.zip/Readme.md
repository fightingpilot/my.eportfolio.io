To setup the PostgreSQL database correct, please follow the following steps:
	1.	Run create_schema.sql
	2.	Use a GIS to add the shapes areas and geschaefte to the schema.
		For areas use "areas" as table name and for geschaefte use "pois" as table name.
		For better performance please make sure that a spatial index created while importing the data! This might have no big effects in this example,
		but if more spatial data is added, the DB could become slow querying this data.
	3.	Run db_setup.sql to create tables, views and fill the tables with the data.