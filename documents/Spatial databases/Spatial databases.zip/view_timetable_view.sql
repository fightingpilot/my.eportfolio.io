create view eot.timetable_view as
	select
	eot.pois.name as stage,
	eot.timetable.act,
	eot.timetable.day,
	eot.timetable.start_time,
	eot.timetable.end_time,
	eot.timetable.type,
	eot.pois.geom
	from
	eot.timetable
	left outer join
	eot.pois
	on
	eot.timetable.stage = eot.pois.id
	order by eot.pois.name