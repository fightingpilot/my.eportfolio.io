create view eot.festival_area as
	select
	eot.pois.name,
	eot.pois.type,
	eot.pois.geom
	from
	eot.pois,
	eot.areas
	where
	eot.areas.name = 'Festival Area'
	and
	st_intersects(eot.pois.geom, eot.areas.geom)