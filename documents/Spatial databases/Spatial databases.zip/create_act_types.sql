create table eot.act_types(
	type text primary key
	)