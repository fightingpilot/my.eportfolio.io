insert into eot.act_types (type)
	values
		('music'),
		('party'),
		('others')