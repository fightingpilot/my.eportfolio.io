create view eot.stages_view as
	select
	*
	from
	eot.pois
	where type = 'stage'