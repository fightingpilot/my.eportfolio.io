insert into eot.days (day)
	values
		('monday'),
		('tuesday'),
		('wednesday'),
		('thursday'),
		('friday'),
		('saturday'),
		('sunday')