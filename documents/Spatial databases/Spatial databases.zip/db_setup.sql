create table eot.acts(
	name text primary key
	);

create table eot.act_types(
	type text primary key
	);

create table eot.days(
	day text primary key
	);

create table eot.timetable(
	day text not null,
	start_time time not null,
	end_time time not null,
	act text not null,
	stage bigint not null,
	type text not null,
	description text,
	primary key(day, start_time, end_time, act, stage),
	constraint fk_day
		foreign key(day)
			references eot.days
			on delete cascade,
	constraint fk_act
		foreign key(act)
			references eot.acts(name)
			on delete cascade,
	constraint fk_stage
		foreign key(stage)
			references eot.pois(id)
			on delete cascade,
	constraint fk_type
		foreign key(type)
			references eot.act_types(type)
			on delete cascade
	);

create table eot.opening_hours(
	poi_id bigint not null,
	open time not null,
	close time not null,
	day text not null,
	primary key(poi_id, open, close, day),
	constraint fk_poi_id
		foreign key(poi_id)
			references eot.pois(id)
			on delete cascade,
	constraint fk_day
		foreign key(day)
			references eot.days(day)
			on delete cascade
	);

insert into eot.acts (name)
	values
		('#hurricaneswimteam'),
		('betontod'),
		('enter shikari'),
		('papa roach'),
		('parkway drive'),
		('die toten hosen'),
		('shame'),
		('alice merton'),
		('cigarettes after sex'),
		('bosse'),
		('bilderbuch'),
		('tame impala'),
		('neonschwarz'),
		('teesy'),
		('leoniden'),
		('ufo361'),
		('trettmann'),
		('black honey'),
		('pond'),
		('gurr'),
		('die höchste eisenbahn'),
		('flux pavilion'),
		('abramowicz'),
		('schmutzki'),
		('zebrahead'),
		('frank turner & the sleeping souls'),
		('flogging molly'),
		('bloc party'),
		('annenmaykantereit'),
		('mumford & sons'),
		('the toten crackhuren im kofferraum'),
		('idles'),
		('fünf sterne deluxe'),
		('die orsons'),
		('257ers'),
		('the wombats'),
		('macklemore'),
		('steve aoki'),
		('the dirty nil'),
		('alex mofa gang'),
		('montreal'),
		('muff potter'),
		('la dispute'),
		('me first & the gimme gimmes'),
		('descendents'),
		('highheelsneakers'),
		('rosborough'),
		('syml'),
		('enno bunger'),
		('johnny marr'),
		('pascow'),
		('moguai'),
		('swmrs'),
		('skinny lister'),
		('you me at six'),
		('royal republic'),
		('wolfmother'),
		('christine and the queens'),
		('foo fighters'),
		('mavi phoenix'),
		('grossstadtgeflüster'),
		('bears den'),
		('the streets'),
		('interpol'),
		('the cure'),
		('lion'),
		('sookee'),
		('yung hurn'),
		('ok kid'),
		('faber'),
		('bausa'),
		('the gardener & the tree'),
		('sea girls'),
		('ten tonnes'),
		('alma'),
		('lauv'),
		('elderbrook'),
		('motorbooty!'),
		('buzz beat boutique'),
		('dj frank eichstädt'),
		('hansemädchen'),
		('beauty & the beats'),
		('radio havanna'),
		('querbeat'),
		('d.klang'),
		('slammer filet'),
		('special guest'),
		('ulf'),
		('steiner & madlaina'),
		('razz'),
		('the sherlocks'),
		('danger dan');

insert into eot.act_types (type)
	values
		('music'),
		('party'),
		('others');

insert into eot.days (day)
	values
		('monday'),
		('tuesday'),
		('wednesday'),
		('thursday'),
		('friday'),
		('saturday'),
		('sunday');

insert into eot.timetable (day, start_time, end_time, act, stage, type, description)
	values
		('thursday', '18:00', '19:00', 'hansemädchen', 5, 'music', ''),
		('thursday', '19:00', '20:30', 'beauty & the beats', 5, 'music', ''),
		('thursday', '21:00', '22:00', 'radio havanna', 5, 'music', ''),
		('thursday', '22:30', '23:45', 'montreal', 5, 'music', ''),
		('friday', '00:15', '01:30', 'querbeat', 5, 'music', ''),
		('friday', '01:30', '03:00', 'd.klang', 5, 'party', ''),
		('thursday', '22:00', '05:00', 'dj frank eichstädt', 119, 'party', ''),
		('friday', '11:00', '12:00', 'slammer filet', 5, 'others', 'poetry slam'),
		('friday', '12:30', '13:30', 'special guest', 5, 'others', ''),
		('friday', '15:00', '15:30', '#hurricaneswimteam', 123, 'music', ''),
		('friday', '16:00', '16:45', 'betontod', 123, 'music', ''),
		('friday', '17:15', '18:15', 'enter shikari', 123, 'music', ''),
		('friday', '19:00', '20:00', 'papa roach', 123, 'music', ''),
		('friday', '20:45', '22:00', 'parkway drive', 123, 'music', ''),
		('friday', '22:45', '00:45', 'die toten hosen', 123, 'music', ''),
		('friday', '15:30', '16:15', 'shame', 124, 'music', ''),
		('friday', '16:45', '17:30', 'alice merton', 124, 'music', ''),
		('friday', '18:15', '19:15', 'cigarettes after sex', 124, 'music', ''),
		('friday', '20:00', '21:00', 'bosse', 124, 'music', ''),
		('friday', '22:00', '23:00', 'bilderbuch', 124, 'music', ''),
		('saturday', '00:30', '02:00', 'tame impala', 124, 'music', ''),
		('friday', '16:15', '17:00', 'neonschwarz', 125, 'music', ''),
		('friday', '17:30', '18:30', 'teesy', 125, 'music', ''),
		('friday', '19:15', '20:15', 'leoniden', 125, 'music', ''),
		('friday', '21:00', '22:00', 'ufo361', 125, 'music', ''),
		('friday', '23:00', '24:00', 'trettmann', 125, 'music', ''),
		('friday', '15:30', '16:15', 'black honey', 119, 'music', ''),
		('friday', '16:45', '17:30', 'pond', 119, 'music', ''),
		('friday', '18:15', '19:15', 'gurr', 119, 'music', ''),
		('friday', '20:00', '21:00', 'die höchste eisenbahn', 119, 'music', ''),
		('friday', '22:00', '23:00', 'flux pavilion', 119, 'music', ''),
		('friday', '23:00', '03:00', 'motorbooty!', 5, 'party', ''),
		('saturday', '00:45', '05:00', 'buzz beat boutique', 119, 'party', ''),
		('saturday', '11:00', '11:30', 'ulf', 5, 'others', ''),
		('saturday', '12:00', '12:30', 'steiner & madlaina', 5, 'others', ''),
		('saturday', '13:00', '13:45', 'razz', 5, 'others', ''),
		('saturday', '12:00', '12:30', 'abramowicz', 123, 'music', ''),
		('saturday', '13:00', '13:45', 'schmutzki', 123, 'music', ''),
		('saturday', '14:15', '15:00', 'zebrahead', 123, 'music', ''),
		('saturday', '15:45', '16:45', 'frank turner & the sleeping souls', 123, 'music', ''),
		('saturday', '17:30', '18:30', 'flogging molly', 123, 'music', ''),
		('saturday', '19:15', '20:15', 'bloc party', 123, 'music', ''),
		('saturday', '21:15', '22:15', 'annenmaykantereit', 123, 'music', ''),
		('saturday', '23:15', '00:45', 'mumford & sons', 123, 'music', ''),
		('saturday', '12:30', '13:15', 'the toten crackhuren im kofferraum', 124, 'music', ''),
		('saturday', '13:45', '14:30', 'idles', 124, 'music', ''),
		('saturday', '15:00', '15:45', 'fünf sterne deluxe', 124, 'music', ''),
		('saturday', '16:45', '17:45', 'die orsons', 124, 'music', ''),
		('saturday', '18:30', '19:45', '257ers', 124, 'music', ''),
		('saturday', '20:30', '21:45', 'the wombats', 124, 'music', ''),
		('saturday', '22:30', '23:45', 'macklemore', 124, 'music', ''),
		('sunday', '00:45', '02:00', 'steve aoki', 124, 'music', ''),
		('saturday', '13:00', '13:45', 'the dirty nil', 125, 'music', ''),
		('saturday', '14:15', '15:15', 'alex mofa gang', 125, 'music', ''),
		('saturday', '15:45', '16:45', 'montreal', 125, 'music', ''),
		('saturday', '17:30', '18:30', 'muff potter', 125, 'music', ''),
		('saturday', '19:30', '20:30', 'la dispute', 125, 'music', ''),
		('saturday', '21:30', '22:30', 'me first & the gimme gimmes', 125, 'music', ''),
		('saturday', '23:30', '00:30', 'descendents', 125, 'music', ''),
		('saturday', '12:30', '13:00', 'highheelsneakers', 119, 'music', ''),
		('saturday', '13:45', '14:15', 'rosborough', 119, 'music', ''),
		('saturday', '15:00', '15:45', 'syml', 119, 'music', ''),
		('saturday', '16:45', '17:45', 'enno bunger', 119, 'music', ''),
		('saturday', '18:30', '19:30', 'johnny marr', 119, 'music', ''),
		('saturday', '20:30', '21:30', 'pascow', 119, 'music', ''),
		('saturday', '22:30', '23:45', 'moguai', 119, 'music', ''),
		('saturday', '23:00', '03:00', 'motorbooty!', 5, 'party', ''),
		('sunday', '00:45', '05:00', 'buzz beat boutique', 119, 'party', ''),
		('sunday', '11:00', '12:30', 'slammer filet', 5, 'others', 'poetry slam'),
		('sunday', '13:00', '13:30', 'the sherlocks', 5, 'others', ''),
		('sunday', '14:00', '14:45', 'danger dan', 5, 'others', ''),
		('sunday', '12:00', '12:30', 'swmrs', 123, 'music', ''),
		('sunday', '13:00', '13:45', 'skinny lister', 123, 'music', ''),
		('sunday', '14:15', '15:15', 'you me at six', 123, 'music', ''),
		('sunday', '15:45', '16:45', 'royal republic', 123, 'music', ''),
		('sunday', '17:15', '18:30', 'wolfmother', 123, 'music', ''),
		('sunday', '19:00', '20:15', 'christine and the queens', 123, 'music', ''),
		('sunday', '22:00', '00:00', 'foo fighters', 123, 'music', ''),
		('sunday', '12:30', '13:00', 'mavi phoenix', 124, 'music', ''),
		('sunday', '13:30', '14:15', 'grossstadtgeflüster', 124, 'music', ''),
		('sunday', '14:45', '15:45', 'bears den', 124, 'music', ''),
		('sunday', '16:15', '17:15', 'the streets', 124, 'music', ''),
		('sunday', '17:45', '19:00', 'interpol', 124, 'music', ''),
		('sunday', '19:45', '22:00', 'the cure', 124, 'music', ''),
		('sunday', '12:00', '12:30', 'lion', 125, 'music', ''),
		('sunday', '13:00', '13:45', 'sookee', 125, 'music', ''),
		('sunday', '14:15', '15:15', 'yung hurn', 125, 'music', ''),
		('sunday', '15:45', '16:45', 'ok kid', 125, 'music', ''),
		('sunday', '17:15', '18:30', 'faber', 125, 'music', ''),
		('sunday', '19:15', '20:30', 'bausa', 125, 'music', ''),
		('sunday', '12:30', '13:00', 'the gardener & the tree', 119, 'music', ''),
		('sunday', '13:30', '14:45', 'sea girls', 119, 'music', ''),
		('sunday', '15:00', '15:45', 'ten tonnes', 119, 'music', ''),
		('sunday', '16:30', '17:15', 'alma', 119, 'music', ''),
		('sunday', '18:15', '19:15', 'lauv', 119, 'music', ''),
		('sunday', '20:30', '22:00', 'elderbrook', 119, 'music', ''),
		('sunday', '23:00', '03:00', 'motorbooty!', 5, 'music', '');

insert into eot.opening_hours (poi_id, open, close, day)
	values
		(2, '12:00', '24:00', 'thursday'),
		(2, '00:00', '24:00', 'friday'),
		(2, '00:00', '24:00', 'saturday'),
		(2, '00:00', '24:00', 'sunday'),
		(2, '00:00', '12:00', 'monday'),
		(21, '12:00', '24:00', 'thursday'),
		(21, '06:00', '24:00', 'friday'),
		(21, '06:00', '24:00', 'saturday'),
		(21, '06:00', '24:00', 'sunday'),
		(21, '06:00', '12:00', 'monday'),
		(8, '09:00', '24:00', 'thursday'),
		(8, '00:00', '24:00', 'friday'),
		(8, '00:00', '24:00', 'saturday'),
		(8, '00:00', '24:00', 'sunday'),
		(8, '00:00', '15:00', 'monday');

create view eot.stages_view as
	select
	*
	from
	eot.pois
	where type = 'stage';

create view eot.festival_area as
	select
	eot.pois.name,
	eot.pois.type,
	eot.pois.geom
	from
	eot.pois,
	eot.areas
	where
	eot.areas.name = 'Festival Area'
	and
	st_intersects(eot.pois.geom, eot.areas.geom);

create view eot.campsite_area as
	select
	eot.pois.name,
	eot.pois.type,
	eot.pois.geom
	from
	eot.pois,
	eot.areas
	where
	eot.areas.name = 'Campsite Area'
	and
	st_intersects(eot.pois.geom, eot.areas.geom);

create view eot.help_me as
	select
	eot.pois.name,
	eot.pois.geom
	from
	eot.pois
	where
	eot.pois.type = 'emergency';

create view eot.timetable_view as
	select
	eot.pois.name as stage,
	eot.timetable.act,
	eot.timetable.day,
	eot.timetable.start_time,
	eot.timetable.end_time,
	eot.timetable.type,
	eot.pois.geom
	from
	eot.timetable
	left outer join
	eot.pois
	on
	eot.timetable.stage = eot.pois.id
	order by eot.pois.name;