create view eot.help_me as
	select
	eot.pois.name,
	eot.pois.geom
	from
	eot.pois
	where
	eot.pois.type = 'emergency'