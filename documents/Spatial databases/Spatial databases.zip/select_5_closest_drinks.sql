select
*,
st_distance('SRID=3857;POINT(1059835 7012301)', eot.pois.geom) as distance
from
eot.pois
where
type = 'drinks'
order by distance
limit 5;