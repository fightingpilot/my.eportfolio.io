create table eot.timetable(
	day text not null,
	start_time time not null,
	end_time time not null,
	act text not null,
	stage bigint not null,
	type text not null,
	description text,
	primary key(day, start_time, end_time, act, stage),
	constraint fk_day
		foreign key(day)
			references eot.days
			on delete cascade,
	constraint fk_act
		foreign key(act)
			references eot.acts(name)
			on delete cascade,
	constraint fk_stage
		foreign key(stage)
			references eot.pois(id)
			on delete cascade,
	constraint fk_type
		foreign key(type)
			references eot.act_types(type)
			on delete cascade
	)