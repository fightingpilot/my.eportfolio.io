create view eot.campsite_area as
	select
	eot.pois.name,
	eot.pois.type,
	eot.pois.geom
	from
	eot.pois,
	eot.areas
	where
	eot.areas.name = 'Campsite Area'
	and
	st_intersects(eot.pois.geom, eot.areas.geom)