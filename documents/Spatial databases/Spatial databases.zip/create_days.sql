create table eot.days(
	day text primary key
	)