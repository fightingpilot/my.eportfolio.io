create table eot.opening_hours(
	poi_id bigint not null,
	open time not null,
	close time not null,
	day text not null,
	primary key(poi_id, open, close, day),
	constraint fk_poi_id
		foreign key(poi_id)
			references eot.pois(id)
			on delete cascade,
	constraint fk_day
		foreign key(day)
			references eot.days(day)
			on delete cascade
	)