create table eot.acts(
	name text primary key
	)