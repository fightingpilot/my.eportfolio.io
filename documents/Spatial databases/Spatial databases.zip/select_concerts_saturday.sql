select
*
from
eot.timetable_view
where
day = 'saturday'
and
type = 'music'
order by
start_time;